To install RealChute, simply merge the included GameData folder with the one in your KSP directory.

NOTE: AS OF 0.25, REALCHUTE IS DISABLED ON WINDOWS 64BIT INSTALLS. GIVEN SQUAD IS RELEASING
UNSTABLE 64BIT BUILDS, THIS MOD WILL NOT RUN ON THEM. THIS ALSO APPLIES TO THE COMMUNITY
HACK INTO 64BIT.


//-------------------------------------------------------//
-- Changelog--
February 4th 2016
v1.3.2.7
-Fixed an issue with parachutes not having a staging icon when on the same part as one disabling the icon

December 2nd 2015 (second take)
v1.3.2.6
-Reuploaded with the correct binaries, not the RealChute 2 ones, won't crash anymore. Sorry.

December 2nd 2015
v1.3.2.5
-Fixed a bug with early reentry giving chutes an exagerated amount of heat (thanks to Starwaster!)

November 10th 2015
v1.3.2.4
-Updated chute heat/aero failures to new changes
-Added indicator for chute deployment safety through the staging icon's background
-Now using MM 2.6.13
-Compiled to KSP v1.0.5

May 2nd 2014
v1.3.2.3
-Updated flags to DDS files, thanks to sumghai again
-Slight bugfix to parachute heating, they now heat, much, much, MUCH faster, as they should.
-Fixed a bug with minimum deployment pressure being in kPa, allowing deployment way too early

May 1st 2015
v1.3.2.2
-Parachutes can now burn up during reentry shock heating, each material has it's own characteristics
-Added a MM node for the new stock radial drogue
-Updated all parachute max temperature values
-sumghai converted all the part textures to DDS for faster loading

April 28th 2015
v1.3.2.1
*Hotfix*
-Fixed the breeding problem with the AppLauncher button
-Fixed the ConfigNode persistence issues with ModuleManager
-Fixed the DragCubes weight problem of the stock Module
-Bundled ModuleManager v2.6.1

April 27th 2015
v1.3.2
*KSP 1.0 compatibility update*
-Updated aerodynamics reference to correctly get new atmospheric values.
-Fixed a few GUI issues all around

April 2nd 2015
v1.3.1
-Removed all this tasty bacon. Wasn't the best parachute.
-Improved enum parsing/tostring, will serve in the future

April 1st 2015
v1.3.3.7
-Optimized toastiness
-The amount of snacks has increased by 401%!
-Now with brand new flavour!
-MOAR

March 12th 2015
v1.3
-Massive optimization of every line of code in RealChute. Literally. Everything.
-Massive optimizations of all the GUIs and of the editor window.
-Presets no longer save the target body, so you can easily apply any preset to any body
-FAR compatibility fixed, previous versions would not correctly use the fetched values
-You can now select if only engineers can repack parachutes in career mode
-You can also select the minimum level required for engineers to repair parachutes in career mode (0 to 5)
-Complying with the last two changes, fixed the bug with engineer levels and repacking in career mode
-Stock parachutes have been removed from the Utility tab and now only appear in the Parachutes tab
-Did I say massive optimization?

December 27th 2014
v1.2.6.3
*Hotfix*
-Reverted the editor GUI changes which caused CoM bugs in flight
-Fixed a bug where stock chutes would not apply parachute model changes correctly
-Only lvl 1+ engineers can repack chutes anymore

December 26th 2014
v1.2.6.2
-Fixed compatibility issue with FAR
-Added a right click menu to modify the size of the parachute case if the action groups are not available yet
-Added a setting which automatically adjusts the size of the canopy while changing case size through right click menu
-New editor RealChute icon by sumghai!
-RealChute logo updated to be clearer in the filter by manufacturer tab
-Moved parachute specific GUI to it's own object
-Fixed a bug where the combo chute would have two main sized chutes
-Updated to ModuleManager 2.5.6
-RealChute parts are now only visible in the "Parachutes" category
-Fixed a bug where RealChute contracts would not display the RealChute/Wenkel logos correctly

December 17th 2014
v1.2.6.1
-KSP 0.90 compatibility update
-Added a parachutes filtering tab in the "filter by function" category
-Changed the default RealChute icon in the "filter by module" section to the RealChute icon
-Added a parachute count field in the general part stats section
-Changed the RealChute default module name in the module info section
-Made so that RealChute parts will be invisible if the mod is incompatible with the current KSP version

November 16th 2014
v1.2.6
-Fixed the bugs related to stock chutes
-Fixed the bug related to parachutes not deploying on first staging action
-Fixed the bug where you could no longer repack if a loading sequence took place ater deployment
-Fixed the numerous bugs with quicksaving/quickloading when parachutes are deployed
-Made part GUI display logic more fluid
-Small optimizations to the editor GUI

October 9th 2014
v1.2.5.3
-Probably fixed the bug when loading crafts

October 8th 2014 (take two)
v1.2.5.2
-Win64bit detecting changed to prevent it to be disabled
-Fixed typo in the SovietPack MM config
-Fixed potential bug with the AppLauncher button
-Corrected the Agents.cfg file to have the correct URLs to the logos and prevent dumb stock bug

October 8th 2014
v1.2.5.1
-Updated to new license

October 7th 2014
v1.2.5
-Fixed the bug where parachutes would disappear during quicksave/quickload process
-Fixed repack bug after reloading a craft with expanded chutes
-The SpaceCenter icon is now added to the stock Applauncher
-RealChute is now part of Wenkel Corporation
-Wenkel Corporation and RealChute flags
-Wenkel Corporation and RealChute are new agencies
-Entry cost reviewed for all chutes
-Added an option to target a specific landing altitude
-Now using a new timer device which follows game time
-Said timer sets parachute deployment correctly through time.
-Upgraded to CompatibilityChecker v4, RealChute is disabled on Windows 64bit installs
-ModuleTestSubject added to parachutes
-Now uses ModuleManager 2.5.0
-Moved the editor GUI to a separate object.

August 6th 2014
v1.2.4
-Updated correctly all ModuleManager files
-Added ModuleManager support to Tantares and the KP0110 pod
-Now uses ModuleManager 2.2.1
-Optimized FAR code to not fetch the method each frame
-Optimized the rescaling code once more, radially attached parts should behave better
-All .png files crushed in size without quality loss thanks to dak180
-SpaceCenter icon will no longer be shown over the Astronaut Complex, RnD Building, or Mission Control views
-CompatibilityChecker now checks for KSP 0.24.1 or higher for  procedural part cost
-All ModuleManager files are now package with the rest of the mod, only the needed nodes are loaded

July 27th 2014
v1.2.3
-Implemented procedural cost for all RealChute parts based on canopy diameter and case size
-Refactored a lot of GUI labels to render more efficiently
-Fixed the nasty bug where parts with only a RealChuteModule would not animate
-Fixed bug where minPressure would not persist through scenes
-Tweaked case masses to make more sense, they were quite heavy in the past

July 22nd 2014 (take two)
v1.2.2.2
*Hotfix*
-Hopefully last fix to the symmetry bug

July 22nd 2014
v1.2.2.1
*Hotfix*
-Fixed a bug with symmetry parts (once more)
-Fixed a bug where you could not repack chutes which did not all deploy.

July 21th 2014
v1.2.2
-Fixed a bug where stock chutes with RealChute configuration would break upon reload
-Added a way to remove the Action Groups GUI from the ProceduralChute if needed

July 20th 2014
v1.2.1
-Fixed bug where the stack chute would never work at all
-Fixed bug where crafts with symmetry parts would have a CoM offset bug and not function properly upon reload if the stats had not been applied to counterparts
-Fixed stock parts MM configs to work properly with this update
-SpaceCenter RealChute icon can now be hid by pressing 'h'

July 18th 2014
v1.2
WARNING: ALL VESSELS AND CRAFT FILES WILL BREAK WITH THIS UPDATE. YOU HAVE BEEN WARNED.
-v0.24 compatibility, built to work on Windows x64
-Completely changed the way multiple chutes on a part are handled�
-Very large part of the code refactored, once again
-Options from the RealChute_Settings.cfg file are now available to be tweaked from the SpaceCenter, icon gracefully offered by sumghai
-Parachutes are now contained into PARACHUTE{} nodes inside PART configs
-The plugin can now handle an indefinite amount of parachutes on a single part
-Various small bugfixes
-Now uses ModuleManager v2.2.0

April 27th 2014 (take two)
v1.1.0.1
*Hotfix*
-Fixed a problem with parts having no size node

April 27th 2014
v1.1
-Extensive code refactoring in both PartModules to clean up a little (no, a lot really)
-Augmented FAR support: when FAR is installed, RealChute will now fetch it's density values
-New size nodes allow changing the attach nodes size when cycling through the different selections
-Presets are now a thing: You can create them, apply them, delete them, but not eat them
-A wide selection of presets are included by default to mimick all the past chutes and allow for quick parachute modification
-Stock chutes will now use the RealChute canopies, and will have procedural size according to their diameter
-Better support for the settings file
-Cleaned the editor GUI a little
-Now uses ModuleManager v2.0.3

April 18th 2014
v1.0.5
-Fixed the bug with secondary chutes not deploying
-Maximum deployment height/pressure now depend on target planet
-Added automatic deployment on ground contact with intend of usage for drag chutes
-Added possibility to compute parachute diameter from empty ship mass
-Applying stats to symmetry parts will now copy over all the fields.
-Added descriptions to materials
-Size cycling swapped to be more intuitive
-April fools prank can be reenabled through the RealChute_Settings.cfg

April 1st 2014 (third try)
v1.0.4.1
*Hotfix*
-Refixed target speed range for drogue chutes

April 1st 2014 (serious edition)
v1.0.4
-Removed the Arpil Fool's prank
-Bumped drogue target speed to 5000m/s
-Fixed potential division by zero bug
-New part descriptions, graciously offered by Duxwing

April 1st 2014
v1.0.3.37
-Fixed the tiny chutes appearing in the editor
-Fixed the last bugs with parachute texture/canopy model not updating correctly
-Fixed symmetry counterparts not having the right deployed/predeployed diameter
-Added procedural diameter to canopies other than RealChute parts
-Fixed pressure/altitude deployment not switching on secondary chutes
-Fixed secondary canopy texture selector not displaying the one said in the module config on first initiation
-Parachute type can now be declared into the module node (main, drogue, drag)
-Removed all legacy parts from the tech tree to avoid confusion
-Moved the cone simple chute to the start TechNode
-KSP v0.23.5 (ARM) compatibility

March 7th 2014
v1.0.3
-Fixed the very small bug where the popup announcing the application worked would not resize after a warning
-Added a display of the current RealChute version on both the editor window and the info window
-Did some very minor code wise improvements around

March 5th 2014
v1.0.2
-Fixed material of the second parachute not updating with his window but with the winodw of the main material
-Similarly to the above, fixed the window of the seconda material showing stats about the main material
-Fixed texture of the second parachute not updating whatsoever
-Fixed symmetry counterparts not ever keeping their size
-Fixed a bug where the "mustGoDown" clause would actually never update for the parachute
-Various tweaks to GUI display (mainly the decimals shown by materials drag coefficient)

March 3rd 2014
v1.0.1.1
*Hotfix*
-Fixed size not remaining in flight properly
-Fixed symmetry counterparts not having the right predpeloyed diameter
-Sorted some problems with the correct updating of part GUI

March 2nd 2014 (take 2)
v1.0.1
*Hotfix*
-Fixed a bug where some fields in the editor window would not update
-Fixed a bug where everything using MM would flat out not work
-Fixed staging activating even from other vessels

March 2nd 2014
v1.0
Editor:
-New editor window which allows tweakaing of parachutes far more easily than stock tweakables
-Said window is accessible in the VAB/SPH through the action group editor panel, by selecting a RealChute part
-Texture, canopy models, and part size can be edited with this window, and only four parts are now necessary
-Old parts are still included to preserve compatibility but are not visible in the editor
-Added a field to prevent parachutes to be tweakable if necessary
-When a texture library is defined, the parachutes will automatically resize to the right diameter

Flight:
-New info window in flight allows seeing the stats of the current parachute
-Predeployment altitude/pressures and deployment altitudes can now be generally tweaked from this window in flight
-When parachutes fail to deploy, their icon will blink red and a message whill show indicating a short reason why
-Parachutes do no need to be moved in a new stage to allow redeployment through staging
-For those who do not like the deployment logic, behaviour can be changed to arm on staging automatically by changing the value in RealChute_Settings.cfg
-Fixed a bug where when coming quickloading or coming back to a flight prevented from repacking correctly

Drag calculator (.exe)
-Repassed the code and added the ability to select the drag coefficient by material

Misc:
-Heavy code repass to fix and optimize multiple things
-The plugin now uses CompatibilityChecker by Majiir to verify if the KSP version is compatible with the plugin

January 9th 2014
v0.3.3.2
*Hotfix*
-Fixed the stack main chutes animation problem

January 8th 2014
v0.3.3.1
*Hotfix*
-Fixed a bug where single parachutes would still not arm propoerly
-Fixed stack main chute configs to have the right canopies so they actually work
-Fixed a problem with staging reset bugging the staging list
-Changed the default drag values of parts to 0.32 to actually match the real stock values
-Changed altitude detection to a faster, safer system
-Hopefully, the change above to altitude detection fixes parachutes deploying too early

January 7th 2014
v0.3.3
-Fixed a bug where dual chutes would not arm
-Changed default predeployment altitudes to 30km for drogues and 25km for mains
-Changed predeployment on drags to 100m and full deployment to 50m
-Switched triple canopies to single canopies on the stack 1.25m main chutes
-Fixed forced orientation so that it actually follows vessel orientation
-Fixed forced orientation remaining even if only one parachute is deployed.
-Small tweaks to attachement notes on stack chutes (thanks to eggrobin)
-Fixed caps being inverted on stack chutes (thanks to eggrobin again for making me notice)
-Changed behaviour or repacked chutes, if not in the last stage, they might not need to be moved to e reactivated.
-Moved the random deployment timer to OnStart() for future MechJeb implementation
-Various tweaks to the tweakables UI controllers
-Fixed a bug where dual chutes with the same material would show "empty" as a second material
-Fixed a bug where full deployment shortly after deployment would result in the animations skipping
-Fixed an annoying and unreliable bug where parachutes would make your craft spin out of control by making the force applied to the part once more

December 18th 2013 (take two)
v0.3.2.1
*Hotfix*
-Fixed the bug where dual parachutes would take mass forever
-Fixed a bug with combo chutes having ridiculous starting weight
-Finally fixed the bug with the FASA and Bargain Rocket parachutes, they will now animate properly (big thanks to sirkut)
-All the ModuleManager files are now included with the main download, remove those you don't want.

December 18th 2013
v0.3.2
KSP 0.23 compatibility update!
-Added combo chutes which contain both a drogue and a main for soft landings in one part
-Added the ability to define a second material for the second parachute
-Added the ability to force the parachutes partially in one direction, thus eliminating clipping chutes on dual parts!
-The force is now applied on the whole vessel, so no more weird hangings if the part origin is weird
-Tweakables! Nearly every value that can be changed in the editor can now be. This is only until I set the editor window up on my side.
-Fixed a bug with parachutes facing downwards on reentry
-Added a random deployment delay for parachutes! They will now take between 0 and 1 second to deploy. This is chose randomly for every parachute
-Every parachute now has random "movement noise" different from every other parachutes currently active
-Said random noise will now appear to be much smoother than before
-Usage of the new EFFECTS node has permited to get rid of FXGroups and to remove all those nasty .wav files all around!

Decemer 7th 2013
v0.3.1
*Hotfix*
-Fixed a bug with the mustGoDown/timer clauses
-Fixed a bug with dual chutes not cutting properly
-Fixed yet another bug with predeployment of main chutes always having the same drag
-Added an "reverseOrientation" clause in case a modeller builds the parachute transform the wrong way
-Parachutes no create drag from the very area where they originate from. This means a chute on the side will hang realistically without a CoM offset
-Rescaled all the parachutes to have the real size in game. If you find this too big, tell me on the forum and I'll revise them (note, this is not procedural yet, if you change the part yourself, you need to change the scale)
-Fixed a bug with the calculator when calculating the diameter of multiple chutes
-Added a sound on repack, thanks to ymir9 once again

December 4th 2013
v0.3
-Completely removed stock drag dependancy. The parachutes now calculate drag according to real drag equations
-Given the above, the drag parachutes generate is irrelevant of the mass of the part and now depends of the diameter of the parachute
-Parachutes are now made of different materials, defined in cfg files
-Parachute canopies now weight something which depends on which material they are made of and what is it's area density
-Optimization of the code by about 300 lines as the module is pretty much complete
-New parts with the pack, thanks to sumghai! You can now select between many different parachutes for the job you want to accomplish
-It is now possible to arm a parachute to deploy as soon as it can through action group or part GUI
-Minimal deployment can now be defined by altitude or pressure
-Added FXGroups to parachute cut and repack, and providing a cut sound with the parachutes, offered by ymir9!
-A small program made to help calculating parachute diameters is also included with the download!

November 24th 2013
v0.2.1
*Hotfix*
-Fixed a bug where single parachutes don't show the right icon colours
-Fixed the weird glitchiness of the parachute's orientation in some occasions
-Fixed parachutes not working if not on the current active vessel

November 23rd 2013
v0.2
-Added a compatibility mode for a second parachute on the same part! Can only be used if the parachute has a a
second set of parachute transform/animation
-Reworked deployment code from the ground up to allow the above feature

November 16th 2013
v0.1b
-Fixed the issue where deploying the parachute below the full deployment height would play the second animations faster
-Added sounds on both predeployment and deployment
-Added a deployment timer that will show a countdown on the flight screen
-Added a clause that the ship must go downards to deploy and that will show status on the flight screen
-Fixed a few remaining deployment bugs
-Changed the behaviour of the part GUI to only show when the action is available

November 13th 2013
v0.1.1a
-Hotfix of a few deployment bugs that could cause weird unresponsive parachutes
-Added a "cutAlt" feature to automatically cut a parachute below a certain altitude.

November 12th 2013
v0.1a
-Initial release

//-------------------------------------------------------//
Components of the modules:

--RealChuteModule--
//General
caseMass: mass of the case of the parachute (what you would normally put at "mass = xx" (put it there too though))
timer: time before deployment after the part has been activated in seconds
mustGoDown: whether or not the craft has to be going downwards to deploy (true/false)
cutSpeed: speed at which the parachute will automatically cut when on the ground in m/s
spareChutes: amount of times a parachute can be repacked (set to -1 if you want to repack it as much as you want)
reverseOrientation: check this to true if the transform was built backwards, else don't put this in at all

//Main parachute
PARACHUTE
{
  material: what material the parachute is made out (must be initiated in a MATERIAL{} node)
  preDeployedDiameter: diameter of the parachute when predeployed
  deployedDiameter: diameter of the parachute when deployed
  minIsPressure: whether the value in "minDeployment" is pressure or altitude (true/false)
  minDeployment: minimum altitude or at which the parachute predeploy (if minIsPressure = false)
  minPressure: minimum pressure at which the parachute will predeploy (if minIsPressure = true)
  deploymentAlt: altitude at which the parachute will fully deploy
  cutAlt: altitude at which the parachute will automatically cut (set this to -1 if you don't want an autocut at a certain altitude)
  preDeploymentSpeed: time required to predeploy the parachute in seconds (affects how fast it decelerates)
  deploymentSpeed: time required to deploy the parachute in seconds (affects how fast it decelerates)
  preDeploymentAnimation: name of the predeployment animation (from the model)
  deploymentAnimation: name of the deployment animation (from the model)
  parachuteName: name of the canopy of the parachute (from the model)
  capName: name of the protective cap of the parachute (from the model)
  forcedOrientation: angle to angle the cute at from the center of the part (greater than 0, lower than 90)
}
//Add as many PARACHUTE{} nodes as you want parachutes on the part

--ProceduralChute--
textureLibrary: name of the texture library to get textures and models from
type: type of parachute this is refered as in the texture library
currentCase: current parachute case texture (from the texture library)
currentCanopies: current canopy texture for the main chute (from the texture library)
currentTypes: current type of the main chute (Main, Drogue, Drag), defaulted to Main
isTweakable: if the Action Groups GUI appears or not.
//Size nodes
SIZE
{
  size: rescaling vector for the part (x, y, z)
  caseMass: case mass for this size
  sizeID: generic ID for this size. Can be whatever you want, but know that presets will use this to find the right size.
  topNode: position of the top node at this size
  topNodeSize: size of the top AttachNode at this size
  bottomNode: position of the bottom node at this size
  bottomNodeSize sixe of the bottom AttachNode at this size
}
//Add as many as you want sizes for your part

--Texture library--
TEXTURE_LIBRARY
{
  name: name of the library

  CASE_TEXTURE
  {
     name: name of this case texture
     types: types of parachute this texture can apply to (separate each by a comma)
     textureURL: string url of the texture from the GameData folder
  }

  CANOPY_TEXTURE
  {
     name: name of this canopy texture
     textureURL: string url of the texture from the GameData folder
  }

  CANOPY_MODEL
  {
     name: name of this canopy model
     diameter: diameter of a single canopy at (1, 1, 1)
     count: number of visible canopies on this model
     maxDiam: max deployed diameter possible for this model
     CHUTE
     {
        modelURL: string url of the model from the GameData folder
        transformName: name of the parachute transform
        preDepAnim: name of the predeployment animation
        depAnim: name of the deployment animation
     }
     //Add as many of those as you want this type of chute to have, models must have different transform names
  }
}

--Material node--
MATERIAL
{
  name: name of the material (string name you put in the PartModule)
  description: short description of the material
  areaDensity: density of the material in t/m�
  dragCoefficient: drag coefficient of this material (recommended to not go below 0.5 and above 2)
}

--Effects node--
EFFECTS
{
  rcpredeploy  //name of the predeployment effect
  {
     AUDIO
     {
        channel = Ship
        clip = sound_parachute_deploy
        volume = 1
     }
  }
  rcdeploy  //name of the deployment effect
  {
     AUDIO
     {
        channel = Ship
        clip = sound_parachute_single
        volume = 1
     }
  }
  rccut  //name of the cut effect
  {
     AUDIO
     {
        channel = Ship
        clip = RealChute/Sounds/sound_parachute_cut
        volume = 1
     }
  }
  rcrepack  //name of the repack effect
  {
     AUDIO
     {
        channel = Ship
        clip = RealChute/Sounds/sound_parachute_repack
        volume = 1
     }
  }
}

//-------------------------------------------------------//
RealChute.dll was made by stupid_chris
The parts provided with the pack were all made by sumghai
The parachute cut and repack sound were made by ymir9

Forum thread: http://forum.kerbalspaceprogram.com/threads/57988
Source code: https://github.com/StupidChris/RealChute

License:
You are free to copy, fork, and modify RealChute as you see fit. However,
redistribution is only permitted for unmodified versions of RealChute,
and under attribution clause. If you want to distribute a modified version
of RealChute, be it code, textures, configs, or any other asset and piece 
of work, you must get my explicit permission on the matter through a private
channel, and must also distribute it through the attribution clause, and must
make it clear to anyone using your modification of my work that they must
report any problem related to this usage to you, and not to me. This clause
expires if I happen to be inactive (no connection) for a period of 90
days on the official KSP forums. In that case, the license reverts back to
CC-BY-NC-SA 4.0 INTL.

License and source code for ModuleManager.dll:
http://forum.kerbalspaceprogram.com/threads/55219